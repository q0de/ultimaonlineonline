/**
 * UO Tile Sets - CLEAN VERSION
 * Only includes the most basic, known-good tessellating tiles
 * 
 * KEY INSIGHT: UO tiles come in groups of 4 that tessellate together.
 * These are the PURE CENTER tiles - no edges or transitions.
 */

export const UO_TILE_SETS_CLEAN = {
    // Pure grass - the most basic green grass tiles
    'grass': [
        ['0x0003', '0x0004', '0x0005', '0x0006'],  // Basic green grass
    ],
    
    // Pure sand - basic tan sand
    'sand': [
        ['0x0016', '0x0017', '0x0018', '0x0019'],  // Basic sand
    ],
    
    // Pure water
    'water': [
        ['0x00A8', '0x00A9', '0x00AA', '0x00AB'],  // Basic water
    ],
    
    // Pure forest - darker green with leaves
    'forest': [
        ['0x00C4', '0x00C5', '0x00C6', '0x00C7'],  // Basic forest floor
    ],
    
    // Pure dirt - brown earth
    'dirt': [
        ['0x0071', '0x0072', '0x0073', '0x0074'],  // Basic brown dirt
    ],
    
    // Pure rock/mountain
    'rock': [
        ['0x00E4', '0x00E5', '0x00E6', '0x00E7'],  // Basic grey rock
    ],
    
    // Pure jungle
    'jungle': [
        ['0x00AC', '0x00AD', '0x00AE', '0x00AF'],  // Basic jungle
    ],
    
    // Pure furrows (plowed field)
    'furrows': [
        ['0x0009', '0x000A', '0x000B', '0x000C'],  // Basic furrows
    ],
    
    // Cave floor
    'cave': [
        ['0x0245', '0x0246', '0x0247', '0x0248'],  // Cave floor
    ],
    
    // Snow
    'snow': [
        ['0x011A', '0x011B', '0x011C', '0x011D'],  // Basic snow
    ],
};

/**
 * Get a tile from a clean tile set using position-based indexing
 * This ensures adjacent tiles use different tiles from the same set for proper tessellation
 */
export function getCleanTileAtPosition(biome, x, y) {
    const sets = UO_TILE_SETS_CLEAN[biome];
    if (!sets || sets.length === 0) {
        console.warn(`No clean tile set for biome: ${biome}, using grass`);
        return UO_TILE_SETS_CLEAN['grass'][0][0];
    }
    
    // Use the first (and only) set for this biome
    const set = sets[0];
    
    // Use position to pick which of the 4 tiles to use
    // This creates a 2x2 repeating pattern that tessellates perfectly
    const tileIndex = ((x % 2) + (y % 2) * 2) % set.length;
    
    return set[tileIndex];
}

export default UO_TILE_SETS_CLEAN;

