/**
 * UO Transition Tiles - 8-bit Bitmask System
 * 
 * This file handles smooth transitions between biomes using proper
 * tile selection based on 8-neighbor context (cardinal + diagonal).
 * 
 * Includes:
 * - Basic edge and corner tiles for sand-to-grass
 * - Grass transition tiles (0x01A5-0x01AB) for better blending
 * - Feathered grass tiles (0x0375, 0x037E, etc.) for layered effects
 * - Smooth curve tiles (0x03B7-0x03C8) for natural curves
 */

// =============================================================================
// TILE DEFINITIONS
// =============================================================================

// Sand-to-Grass transition tiles (sand tile with grass encroaching)
const SAND_TILES = {
    // Pure sand (no grass neighbors)
    pure: ['0x0016', '0x0017', '0x0018', '0x0019'],
    
    // Edge tiles - half sand, half grass (grass on one side)
    edgeN: '0x0039',   // Grass on North edge
    edgeE: '0x003A',   // Grass on East edge
    edgeS: '0x0037',   // Grass on South edge
    edgeW: '0x0038',   // Grass on West edge
    
    // Outer corners - mostly sand with small grass corner
    cornerNE: '0x003E', // Grass in NE corner
    cornerSE: '0x003B', // Grass in SE corner
    cornerSW: '0x003C', // Grass in SW corner
    cornerNW: '0x003D', // Grass in NW corner
    
    // Inner corners - mostly grass with small sand corner (peninsula tips)
    innerNE: '0x0036', // Sand in NE corner
    innerSE: '0x0033', // Sand in SE corner
    innerSW: '0x0034', // Sand in SW corner
    innerNW: '0x0035', // Sand in NW corner
};

// Pure grass tiles - multiple sets for variety
const GRASS_TILES = {
    // Basic green grass (most common)
    pure: ['0x0003', '0x0004', '0x0005', '0x0006'],
    
    // Grass with foliage/plants - adds visual variety
    withFoliage: ['0x00C0', '0x00C1', '0x00C2', '0x00C3'],
    
    // Additional grass variations
    varied: ['0x007D', '0x007E', '0x007F'],
    
    // More grass variations (0x036F-0x0376 range)
    extra: ['0x036F', '0x0370', '0x0371', '0x0372', '0x0373', '0x0374', '0x0375', '0x0376'],
    
    // All grass tiles combined for random selection
    all: [
        '0x0003', '0x0004', '0x0005', '0x0006',  // Basic
        '0x00C0', '0x00C1', '0x00C2', '0x00C3',  // With foliage
        '0x007D', '0x007E', '0x007F',            // Varied
    ],
};

// Grass transition tiles - grass that blends better at sand boundaries
const GRASS_TRANSITION_TILES = {
    // These are grass tiles with subtle sand hints - use near sand boundaries
    nearSand: ['0x01A5', '0x01A6', '0x01A7', '0x01A8', '0x01A9', '0x01AA', '0x01AB'],
};

// Feathered grass tiles - grass with very subtle sand/dirt hints for layered effects
const FEATHERED_GRASS_TILES = {
    subtle: ['0x0375', '0x037E', '0x0684', '0x012A', '0x012C'],
};

// Smooth curve tiles - for natural curved transitions (sand-to-grass)
const SMOOTH_CURVE_TILES = {
    // These create natural curved transitions instead of sharp corners
    // Range 0x03B7-0x03C8
    curves: [
        '0x03B7', '0x03B8', '0x03B9', '0x03BA', '0x03BB', '0x03BC',
        '0x03BD', '0x03BE', '0x03BF', '0x03C0', '0x03C1', '0x03C2',
        '0x03C3', '0x03C4', '0x03C5', '0x03C6', '0x03C7', '0x03C8'
    ],
    // Specific curve directions (approximate - need visual verification)
    curveNE: ['0x03B7', '0x03B8', '0x03B9'],
    curveSE: ['0x03BA', '0x03BB', '0x03BC'],
    curveSW: ['0x03BD', '0x03BE', '0x03BF'],
    curveNW: ['0x03C0', '0x03C1', '0x03C2'],
};

// Pure water tiles
const WATER_TILES = {
    pure: ['0x00A8', '0x00A9', '0x00AA', '0x00AB'],
};

// =============================================================================
// HELPER FUNCTIONS
// =============================================================================

function getBiomeAt(map, x, y, width, height) {
    if (x < 0 || x >= width || y < 0 || y >= height) return 'grass';
    const biome = map[y][x].biome;
    if (biome === 'forest' || biome === 'jungle') return 'grass';
    return biome;
}

function randomChoice(arr) {
    return arr[Math.floor(Math.random() * arr.length)];
}

function getNeighbors(map, x, y, width, height) {
    return {
        n:  getBiomeAt(map, x, y - 1, width, height),
        ne: getBiomeAt(map, x + 1, y - 1, width, height),
        e:  getBiomeAt(map, x + 1, y, width, height),
        se: getBiomeAt(map, x + 1, y + 1, width, height),
        s:  getBiomeAt(map, x, y + 1, width, height),
        sw: getBiomeAt(map, x - 1, y + 1, width, height),
        w:  getBiomeAt(map, x - 1, y, width, height),
        nw: getBiomeAt(map, x - 1, y - 1, width, height),
    };
}

// =============================================================================
// SAND TRANSITION TILE SELECTION
// =============================================================================

function getSandTransitionTile(neighbors) {
    const { n, ne, e, se, s, sw, w, nw } = neighbors;
    
    const grassN = n === 'grass';
    const grassE = e === 'grass';
    const grassS = s === 'grass';
    const grassW = w === 'grass';
    const grassNE = ne === 'grass';
    const grassSE = se === 'grass';
    const grassSW = sw === 'grass';
    const grassNW = nw === 'grass';
    
    const cardinalGrassCount = [grassN, grassE, grassS, grassW].filter(Boolean).length;
    
    // CASE 1: No grass neighbors - pure sand
    if (!grassN && !grassE && !grassS && !grassW && !grassNE && !grassSE && !grassSW && !grassNW) {
        return randomChoice(SAND_TILES.pure);
    }
    
    // CASE 2: Inner corners - grass on 3 cardinal sides (sand peninsula tip)
    if (cardinalGrassCount >= 3) {
        if (grassN && grassE && grassS && !grassW) return SAND_TILES.innerSW;
        if (grassE && grassS && grassW && !grassN) return SAND_TILES.innerNW;
        if (grassS && grassW && grassN && !grassE) return SAND_TILES.innerNE;
        if (grassW && grassN && grassE && !grassS) return SAND_TILES.innerSE;
        if (grassN && grassE && grassS && grassW) return SAND_TILES.innerNE;
    }
    
    // CASE 3: Two adjacent cardinal grass neighbors - outer corner
    if (cardinalGrassCount === 2) {
        if (grassN && grassE) return SAND_TILES.cornerNE;
        if (grassE && grassS) return SAND_TILES.cornerSE;
        if (grassS && grassW) return SAND_TILES.cornerSW;
        if (grassW && grassN) return SAND_TILES.cornerNW;
        
        // Two opposite cardinal neighbors - narrow channel
        if (grassN && grassS) return SAND_TILES.edgeN;
        if (grassE && grassW) return SAND_TILES.edgeE;
    }
    
    // CASE 4: One cardinal grass neighbor - edge tile
    if (cardinalGrassCount === 1) {
        if (grassN) return SAND_TILES.edgeN;
        if (grassE) return SAND_TILES.edgeE;
        if (grassS) return SAND_TILES.edgeS;
        if (grassW) return SAND_TILES.edgeW;
    }
    
    // CASE 5: Only diagonal grass neighbors - outer corners
    if (cardinalGrassCount === 0) {
        if (grassNE && !grassSE && !grassSW && !grassNW) return SAND_TILES.cornerNE;
        if (grassSE && !grassNE && !grassSW && !grassNW) return SAND_TILES.cornerSE;
        if (grassSW && !grassNE && !grassSE && !grassNW) return SAND_TILES.cornerSW;
        if (grassNW && !grassNE && !grassSE && !grassSW) return SAND_TILES.cornerNW;
        
        if (grassNE) return SAND_TILES.cornerNE;
        if (grassSE) return SAND_TILES.cornerSE;
        if (grassSW) return SAND_TILES.cornerSW;
        if (grassNW) return SAND_TILES.cornerNW;
    }
    
    return randomChoice(SAND_TILES.pure);
}

// =============================================================================
// GRASS TRANSITION TILE SELECTION
// =============================================================================

function getGrassTransitionTile(neighbors) {
    const { n, ne, e, se, s, sw, w, nw } = neighbors;
    
    const sandN = n === 'sand';
    const sandE = e === 'sand';
    const sandS = s === 'sand';
    const sandW = w === 'sand';
    const sandNE = ne === 'sand';
    const sandSE = se === 'sand';
    const sandSW = sw === 'sand';
    const sandNW = nw === 'sand';
    
    const cardinalSandCount = [sandN, sandE, sandS, sandW].filter(Boolean).length;
    const diagonalSandCount = [sandNE, sandSE, sandSW, sandNW].filter(Boolean).length;
    
    // If grass has sand neighbors, use grass transition tiles for better blending
    if (cardinalSandCount > 0 || diagonalSandCount > 0) {
        // Use feathered grass for cells with diagonal sand only
        if (cardinalSandCount === 0 && diagonalSandCount > 0) {
            return randomChoice(FEATHERED_GRASS_TILES.subtle);
        }
        // Use grass transition tiles for cells near sand
        return randomChoice(GRASS_TRANSITION_TILES.nearSand);
    }
    
    // Pure grass - no sand nearby, use varied grass for natural look
    const roll = Math.random();
    if (roll < 0.60) {
        return randomChoice(GRASS_TILES.pure);
    } else if (roll < 0.85) {
        return randomChoice(GRASS_TILES.withFoliage);
    } else {
        return randomChoice(GRASS_TILES.varied);
    }
}

// =============================================================================
// BOUNDARY FINDING
// =============================================================================

function findBoundaryCells(map, width, height, biomeA, biomeB) {
    const boundaries = [];
    
    for (let y = 0; y < height; y++) {
        for (let x = 0; x < width; x++) {
            const myBiome = getBiomeAt(map, x, y, width, height);
            if (myBiome !== biomeA) continue;
            
            const neighbors = getNeighbors(map, x, y, width, height);
            const hasNeighborB = Object.values(neighbors).some(b => b === biomeB);
            
            if (hasNeighborB) {
                boundaries.push({ x, y, neighbors });
            }
        }
    }
    
    return boundaries;
}

// =============================================================================
// MAIN TRANSITION APPLICATION
// =============================================================================

export function apply8BitTransitions(map, width, height) {
    let transitionCount = 0;
    
    // First pass: Set all pure biome tiles with variety
    for (let y = 0; y < height; y++) {
        for (let x = 0; x < width; x++) {
            const tile = map[y][x];
            const biome = tile.biome;
            
            if (biome === 'grass' || biome === 'forest' || biome === 'jungle') {
                // Use varied grass tiles for more natural look
                // 60% basic grass, 25% foliage grass, 15% other variations
                const roll = Math.random();
                if (roll < 0.60) {
                    tile.id = randomChoice(GRASS_TILES.pure);
                } else if (roll < 0.85) {
                    tile.id = randomChoice(GRASS_TILES.withFoliage);
                } else {
                    tile.id = randomChoice(GRASS_TILES.varied);
                }
            } else if (biome === 'sand') {
                tile.id = randomChoice(SAND_TILES.pure);
            } else if (biome === 'water') {
                tile.id = randomChoice(WATER_TILES.pure);
            }
        }
    }
    
    // Second pass: Apply sand transitions (sand cells next to grass)
    const sandBoundaries = findBoundaryCells(map, width, height, 'sand', 'grass');
    console.log(`Found ${sandBoundaries.length} sand boundary cells`);
    
    for (const cell of sandBoundaries) {
        const neighbors = getNeighbors(map, cell.x, cell.y, width, height);
        const transitionTile = getSandTransitionTile(neighbors);
        
        map[cell.y][cell.x].id = transitionTile;
        map[cell.y][cell.x].isTransition = true;
        transitionCount++;
    }
    
    // Third pass: Apply grass transitions (grass cells next to sand)
    // This uses the special grass transition tiles for better blending
    for (let y = 0; y < height; y++) {
        for (let x = 0; x < width; x++) {
            const tile = map[y][x];
            if (tile.biome !== 'grass' && tile.biome !== 'forest' && tile.biome !== 'jungle') continue;
            if (tile.isTransition) continue;
            
            const neighbors = getNeighbors(map, x, y, width, height);
            const hasSandNeighbor = Object.values(neighbors).some(b => b === 'sand');
            
            if (hasSandNeighbor) {
                tile.id = getGrassTransitionTile(neighbors);
                tile.isTransition = true;
                transitionCount++;
            }
        }
    }
    
    console.log(`Applied ${transitionCount} transition tiles total`);
    return transitionCount;
}

// Alias for compatibility
export function applyBoundaryTransitions(map, width, height) {
    return apply8BitTransitions(map, width, height);
}

// Export tile definitions for other modules
export { 
    SAND_TILES, 
    GRASS_TILES, 
    GRASS_TRANSITION_TILES,
    FEATHERED_GRASS_TILES,
    SMOOTH_CURVE_TILES,
    WATER_TILES 
};

// Legacy exports for compatibility
export function calculate8BitBitmask() { return 0; }
export function getSandToGrassTile() { return null; }
export function getTileFromLookup() { return null; }
export function getGrassToSandTile8Bit() { return null; }
export function getSandToGrassTile8Bit() { return null; }
export function getGrassToSandTransition() { return null; }
export function getSandToGrassTransition() { return null; }

export default { apply8BitTransitions, applyBoundaryTransitions, SAND_TILES };
