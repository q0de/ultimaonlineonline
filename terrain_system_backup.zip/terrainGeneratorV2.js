/**
 * Terrain Generator V2 - Proper UO Tile Tessellation
 * 
 * KEY INSIGHT: UO tiles come in GROUPS OF 4 that tessellate together.
 * You must use ALL 4 tiles from the same group for a region - they're designed
 * to fit together like puzzle pieces.
 * 
 * This generator:
 * 1. Uses noise to determine biome regions
 * 2. Picks ONE tile set per region (group of 4 tiles)
 * 3. Uses all 4 tiles from that set within the region
 * 4. Handles transitions at biome boundaries
 */

import { UO_TILE_SETS, getTileFromSet } from '../data/uoTileSets.js';
import { UO_TILE_SETS_CLEAN, getCleanTileAtPosition } from '../data/uoTileSetsClean.js';
import { 
    SAND_TO_GRASS_TRANSITIONS,
    GRASS_TO_SAND_TRANSITIONS, 
    calculateTransitionBitmask, 
    getTransitionTile 
} from '../data/transitionTiles.js';
import { 
    apply8BitTransitions,
    getGrassToSandTransition,
    calculate8BitBitmask
} from '../data/transitionTiles8bit.js';

// Simplex Noise for coherent terrain
class SimplexNoise {
    constructor(seed = Math.random() * 10000) {
        this.p = new Uint8Array(256);
        this.perm = new Uint8Array(512);
        this.permMod12 = new Uint8Array(512);
        
        for (let i = 0; i < 256; i++) {
            this.p[i] = i;
        }
        
        let s = seed;
        for (let i = 255; i > 0; i--) {
            s = (s * 16807) % 2147483647;
            const j = s % (i + 1);
            [this.p[i], this.p[j]] = [this.p[j], this.p[i]];
        }
        
        for (let i = 0; i < 512; i++) {
            this.perm[i] = this.p[i & 255];
            this.permMod12[i] = this.perm[i] % 12;
        }
        
        this.grad3 = [
            [1, 1, 0], [-1, 1, 0], [1, -1, 0], [-1, -1, 0],
            [1, 0, 1], [-1, 0, 1], [1, 0, -1], [-1, 0, -1],
            [0, 1, 1], [0, -1, 1], [0, 1, -1], [0, -1, -1]
        ];
        
        this.F2 = 0.5 * (Math.sqrt(3) - 1);
        this.G2 = (3 - Math.sqrt(3)) / 6;
    }
    
    dot2(g, x, y) {
        return g[0] * x + g[1] * y;
    }
    
    noise2D(x, y) {
        const { F2, G2, perm, permMod12, grad3 } = this;
        
        const s = (x + y) * F2;
        const i = Math.floor(x + s);
        const j = Math.floor(y + s);
        
        const t = (i + j) * G2;
        const X0 = i - t;
        const Y0 = j - t;
        const x0 = x - X0;
        const y0 = y - Y0;
        
        const i1 = x0 > y0 ? 1 : 0;
        const j1 = x0 > y0 ? 0 : 1;
        
        const x1 = x0 - i1 + G2;
        const y1 = y0 - j1 + G2;
        const x2 = x0 - 1 + 2 * G2;
        const y2 = y0 - 1 + 2 * G2;
        
        const ii = i & 255;
        const jj = j & 255;
        
        let n0 = 0, n1 = 0, n2 = 0;
        
        let t0 = 0.5 - x0 * x0 - y0 * y0;
        if (t0 >= 0) {
            t0 *= t0;
            n0 = t0 * t0 * this.dot2(grad3[permMod12[ii + perm[jj]]], x0, y0);
        }
        
        let t1 = 0.5 - x1 * x1 - y1 * y1;
        if (t1 >= 0) {
            t1 *= t1;
            n1 = t1 * t1 * this.dot2(grad3[permMod12[ii + i1 + perm[jj + j1]]], x1, y1);
        }
        
        let t2 = 0.5 - x2 * x2 - y2 * y2;
        if (t2 >= 0) {
            t2 *= t2;
            n2 = t2 * t2 * this.dot2(grad3[permMod12[ii + 1 + perm[jj + 1]]], x2, y2);
        }
        
        return 70 * (n0 + n1 + n2);
    }
}

export class TerrainGeneratorV2 {
    constructor(seed = Date.now()) {
        this.seed = seed;
        this.noise = new SimplexNoise(seed);
        this.tileSetNoise = new SimplexNoise(seed + 1000); // For tile set variation
    }
    
    /**
     * Get biome based on elevation and moisture
     */
    getBiome(elevation, moisture) {
        // Water
        if (elevation < 0.35) return 'water';
        
        // Beach/Sand - narrow band around water
        if (elevation < 0.40) return 'sand';
        
        // Low elevation
        if (elevation < 0.55) {
            if (moisture > 0.6) return 'jungle';
            if (moisture > 0.4) return 'forest';
            return 'grass';
        }
        
        // Medium elevation
        if (elevation < 0.70) {
            if (moisture > 0.5) return 'forest';
            if (moisture < 0.3) return 'dirt';
            return 'grass';
        }
        
        // High elevation
        if (elevation < 0.85) {
            return 'rock';
        }
        
        // Very high = snow/rock
        return 'rock';
    }
    
    /**
     * Pick a tile from the CLEAN tile set using position-based indexing
     * Uses only pure center tiles - no edges or transitions
     */
    getTileFromSetAtPosition(biome, x, y, setIndex = 0) {
        // Use clean tile sets for guaranteed tessellation
        return getCleanTileAtPosition(biome, x, y);
    }
    
    /**
     * Determine which tile set to use for a region
     * Uses noise to create coherent regions that use the same tile set
     */
    getTileSetIndex(biome, x, y) {
        const sets = UO_TILE_SETS[biome];
        if (!sets || sets.length <= 1) return 0;
        
        // Use noise at a larger scale to create coherent regions
        const scale = 0.05; // Larger regions
        const noiseVal = (this.tileSetNoise.noise2D(x * scale, y * scale) + 1) / 2;
        
        return Math.floor(noiseVal * sets.length) % sets.length;
    }
    
    /**
     * Generate a map using proper UO tile tessellation
     */
    generateMap(width, height) {
        const map = [];
        
        // First pass: determine biomes and assign center tiles
        for (let y = 0; y < height; y++) {
            map[y] = [];
            for (let x = 0; x < width; x++) {
                // Use multiple octaves of noise for natural terrain
                const scale1 = 0.02;
                const scale2 = 0.05;
                const scale3 = 0.1;
                
                const e1 = this.noise.noise2D(x * scale1, y * scale1);
                const e2 = this.noise.noise2D(x * scale2 + 100, y * scale2 + 100) * 0.5;
                const e3 = this.noise.noise2D(x * scale3 + 200, y * scale3 + 200) * 0.25;
                
                const elevation = (e1 + e2 + e3 + 1.75) / 3.5; // Normalize to 0-1
                
                // Moisture uses different noise offset
                const m1 = this.noise.noise2D(x * scale1 + 500, y * scale1 + 500);
                const m2 = this.noise.noise2D(x * scale2 + 600, y * scale2 + 600) * 0.5;
                const moisture = (m1 + m2 + 1.5) / 3; // Normalize to 0-1
                
                const biome = this.getBiome(elevation, moisture);
                
                // Get tile set for this region
                const setIndex = this.getTileSetIndex(biome, x, y);
                
                // Get specific tile from the set based on position
                const tileId = this.getTileFromSetAtPosition(biome, x, y, setIndex);
                
                map[y][x] = {
                    id: tileId,
                    biome: biome,
                    elevation: elevation,
                    moisture: moisture,
                    setIndex: setIndex
                };
            }
        }
        
        // Second pass: Apply transitions at biome boundaries
        this.applyTransitions(map, width, height);
        
        return map;
    }
    
    /**
     * Apply transition tiles where different biomes meet
     * Uses 8-bit bitmask for proper corner handling
     */
    applyTransitions(map, width, height) {
        // Use the new 8-bit transition system
        apply8BitTransitions(map, width, height);
        
        // Debug: Log some transition info
        let transitionCount = 0;
        for (let y = 0; y < height; y++) {
            for (let x = 0; x < width; x++) {
                if (map[y][x].isTransition) {
                    transitionCount++;
                }
            }
        }
        console.log(`Applied ${transitionCount} transition tiles using 8-bit system`);
    }
    
    /**
     * Generate a simple test map - SAND in center, GRASS around
     * This is the layout that was working correctly!
     */
    generateTestMap(width = 30, height = 30) {
        const map = [];
        
        // Sand strip in the CENTER
        const sandStart = Math.floor(width / 3);
        const sandEnd = Math.floor(width * 2 / 3);
        
        for (let y = 0; y < height; y++) {
            map[y] = [];
            for (let x = 0; x < width; x++) {
                let biome = 'grass';
                
                // Center: Sand strip
                if (x >= sandStart && x < sandEnd) {
                    biome = 'sand';
                }
                
                // Get tile set for this region
                const setIndex = this.getTileSetIndex(biome, x, y);
                
                // Get specific tile from the set based on position
                const tileId = this.getTileFromSetAtPosition(biome, x, y, setIndex);
                
                map[y][x] = {
                    id: tileId,
                    biome: biome,
                    elevation: 0.5,
                    moisture: 0.5,
                    setIndex: setIndex
                };
            }
        }
        
        // Apply transitions at biome boundaries
        this.applyTransitions(map, width, height);
        
        return map;
    }
}

export default TerrainGeneratorV2;

